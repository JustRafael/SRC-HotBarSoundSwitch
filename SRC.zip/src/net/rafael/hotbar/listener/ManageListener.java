package net.rafael.hotbar.listener;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemHeldEvent;

public class ManageListener implements Listener {

    //---------------------------------------------//
    // DAS PLUGIN WURDE VON JUSTRAFEL PROGRAMMIERT //
    //---------------------------------------------//

    @EventHandler
    public void onItemSwitch(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        player.playSound(player.getLocation(), Sound.NOTE_STICKS , 1, 1);
    }
}
