package net.rafael.hotbar.main;

import net.rafael.hotbar.listener.ManageListener;
import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    //---------------------------------------------//
    // DAS PLUGIN WURDE VON JUSTRAFEL PROGRAMMIERT //
    //---------------------------------------------//

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";

    public void onEnable() {
        System.out.println(ANSI_PURPLE + "HotbarSwitchSound" + ANSI_GREEN + " Plugin gestartet!" + ANSI_RESET);

        init(Bukkit.getPluginManager());
    }

    private void init(PluginManager pluginManager) {
        pluginManager.registerEvents(new ManageListener(), this);
    }

    public void onDisable() {
        System.out.println(ANSI_PURPLE + "HotbarSwitchSound" + ANSI_RED + " Plugin heruntergefahren!" + ANSI_RESET);
    }
}
